Endian Documentation
====================

endian is a simple C++ library for conversion between big and little endian data
representations and provide stream-like interface for accessing a fixed-size
buffer.




Table of Contents
-----------------

.. toctree::
  :maxdepth: 2

  user_api/user_api
  examples/examples
  license


.. toctree::
  :maxdepth: 1

  news
