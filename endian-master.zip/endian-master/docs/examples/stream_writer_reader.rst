Stream writer and reader
========================

This basic example shows how to use the stream writer and reader.

.. literalinclude:: ../../examples/stream_writer_reader.cpp
    :language: c++
    :linenos:
