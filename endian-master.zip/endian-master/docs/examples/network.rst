Network
========================

This basic example shows how to use the network alias.

.. literalinclude:: ../../examples/network.cpp
    :language: c++
    :linenos:
