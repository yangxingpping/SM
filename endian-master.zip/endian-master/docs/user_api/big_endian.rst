.. wurfapi:: class_synopsis.rst
    :selector: big_endian
