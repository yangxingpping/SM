.. wurfapi:: class_synopsis.rst
    :selector: stream_writer