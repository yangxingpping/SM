function is_big_endian()
========================

.. wurfapi:: function_synopsis.rst
    :selector: is_big_endian()

