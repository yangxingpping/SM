.. wurfapi:: class_synopsis.rst
    :selector: little_endian
