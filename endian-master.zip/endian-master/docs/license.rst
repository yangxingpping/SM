License
=======

.. include:: ../LICENSE.rst


